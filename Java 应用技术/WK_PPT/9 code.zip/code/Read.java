import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class Read {
	public static void main(String[] args) throws Exception {
		ObjectInputStream in = new ObjectInputStream(
			new FileInputStream("a.data"));
		Object o = in.readObject();
		in.close();
		Class c = o.getClass();
		System.out.println(c);

	}
}