import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class LockInfo {
  private final Lock lock = new ReentrantLock();
  private int sharedData = 0;

  public void business() throws Exception {
    Thread t = new Thread(new Runnable() {
        @Override
        public void run() {
          lock.lock();
          try {
            try {
              Thread.sleep(100000);
            } catch (InterruptedException e) {
              e.printStackTrace();
            }
            sharedData = 1;
          } finally {
            lock.unlock();
          }
        }
    });
    t.start();
    Thread.sleep(100);
    lock.lock();
    try {
        System.out.println("sharedData:" + sharedData);
    } finally {
        lock.unlock();
    }
  }
  public static void main(String[] args) throws Exception {
    LockInfo li = new LockInfo();
    li.business();  
  }
}