import java.lang.reflect.Method;
import java.io.Serializable;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class Invoke implements Serializable {
	private int i;
	public void f(Integer i) {
		System.out.println("f"+i);
		this.i = i;
	}
	public static void main(String[] args) 
		throws Exception {
		Invoke i = new Invoke();
		i.f(12);
		ObjectOutputStream out = new ObjectOutputStream(
			new FileOutputStream("a.data"));
		out.writeObject(i);
		out.close();
	}
}