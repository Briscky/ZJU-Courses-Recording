//: Parcel1.java
// Creating inner classes

public class Parcel1 {
	static {
		System.out.println("Loading of Parcel1");
	}
	{
		System.out.println("Ctoring of Parcel1");
	}
	class Contents {
		static {
			System.out.println("Loading of Contents");
		}	
		private int i = 11;
		public int value() { return i; }
	}
	class Destination {
		private String label;
		Destination(String whereTo) {
			label = whereTo;
		}
		String readLabel() { return label; }
	}

	// Using inner classes looks just like using any other class, within Parcel1:
	public void ship(String dest) {
		System.out.println("at the beginning of ship");
		Contents c = new Contents();
		Destination d = new Destination(dest);
	}
	public static void main(String[] args) {
		System.out.println("b4 new Parcel1");
		Parcel1 p = new Parcel1();
		System.out.println("b4 ship");
		p.ship("Tanzania");
		Contents c = new Contents();
	}
}