import java.io.* ;

public class DataSave {
	public static void main(String[] args){
		int i=12;//0x12345678;
		double d = 1234.0;
		try {
			// DataOutputStream out = 
			// 	new DataOutputStream(
			// 		new BufferedOutputStream(
			// 			new FileOutputStream("data.bin")));
			// out.writeInt(i);
			// out.writeDouble(d);
			// out.close();
			DataInputStream in = 
				new DataInputStream(
					new BufferedInputStream(
						new FileInputStream("data.bin")));
			int ii = in.readInt();
			double dd = in.readDouble();
			in.close();
			System.out.println(ii);
			System.out.println(dd);
		} catch (Exception e) {
			String err = e.toString();
			System.out.println(err);
		}
	}
}
