//: Contents.java

interface Contents {
	int value();
}
