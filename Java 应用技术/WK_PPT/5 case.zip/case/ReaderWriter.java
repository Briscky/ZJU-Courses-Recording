import java.io.*;

public class ReaderWriter {
	public static void main(String[] args) {
		try{
			BufferedReader stdin = 
				new BufferedReader(
					new InputStreamReader(System.in));
			System.out.print("Enter a line:");
			String line = stdin.readLine();
			BufferedWriter fout = 
				new BufferedWriter(
					new OutputStreamWriter(
						new FileOutputStream("out.txt")));
			fout.write(line);
			fout.close();
		}catch(IOException e){
			System.out.println("IO Exception");
		}
	}
}
