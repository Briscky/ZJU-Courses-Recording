//: FreezeAlien.java
// Create a serialzed output file
import java.io.*;

public class FreezeAlien {
	public static void main(String[] args) throws Exception {
		ObjectOutputStream out = 
			new ObjectOutputStream(
				new FileOutputStream("file.x"));
		Alien zorcon = new Alien();
		out.writeObject(zorcon);
	}
}