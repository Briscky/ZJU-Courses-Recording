//: ThawAlien.java
// Try to recover a serialized file
import java.io.*;

public class ThawAlien {
	public static void main(String[] args) throws Exception {
		ObjectInputStream in = 
			new ObjectInputStream(
				new FileInputStream("file.x"));
		Object mystery = in.readObject();
		System.out.println(mystery.getClass().toString());
	}
}