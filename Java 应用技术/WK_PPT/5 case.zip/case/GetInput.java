import java.io.* ;

class GetInput{
	public static void main(String[] args){
		byte buffer[] = new byte[256];
		try {
			int bytes = System.in.read(buffer,0,256);
			String str = new String(buffer,0,bytes, "GB2312");
			System.out.println(str+":"+bytes+":"+str.length());
		} catch (Exception e) {
			String err = e.toString();
			System.out.println(err);
		}
	}
}
