//: Months.java
// Using interfaces to create groups of constants

public interface Months {
	int
		JANUARY 	= 1,
		FEBRUARY 	= 2,
		MARCH 		= 3,
		APPIL		= 4,
		MAY			= 5,
		JUNE		= 6,
		JULY		= 7,
		AUGUEST		= 8,
		SEPTEMBER	= 9,
		OCTOBER		= 10,
		NOVEMBER	= 11,
		DECEMBER	= 12;
}