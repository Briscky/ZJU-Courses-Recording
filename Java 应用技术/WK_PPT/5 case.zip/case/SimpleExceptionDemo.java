//: c09:SimpleExceptionDemo.java
// Inheriting your own exceptions.

class SimpleException extends Exception {}
class SException extends Exception {}

public class SimpleExceptionDemo {
  public void f() throws SimpleException, SException {
    System.out.println("Throw SimpleException from f()");
    throw new SimpleException();
  }
  public static void main(String[] args) throws SException {
    SimpleExceptionDemo sed = new SimpleExceptionDemo();
    try {
      sed.f();
    } catch(SimpleException e) {
      System.err.println("Caught it!");
    }
  }
} ///:~