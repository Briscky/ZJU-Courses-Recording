import java.io.* ;

class FileApp2{

	public static void main(String[] args){
		byte buffer[] = new byte[80];
		try{
			System.out.println("\nEnter a line to be saved to disk:");
			int bytes = System.in.read(buffer);
			FileOutputStream fileOut = new FileOutputStream("line.txt");
			fileOut.write(buffer,0,bytes);
			
		}
		catch( Exception e){
			String err = e.toString();
			System.out.println(err);
		}
	}
}
	