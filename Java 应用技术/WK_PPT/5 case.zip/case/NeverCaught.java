//: NeverCaugth.java
// Ignoring RuntimeExceptions

public class NeverCaught {
	static void f() throws Exception {
		throw new Exception("From f()");
	}
	static void g() throws Exception  {
		f(); 
	}
	public static void main(String[] args)  throws Exception {
		g();
	}
}
