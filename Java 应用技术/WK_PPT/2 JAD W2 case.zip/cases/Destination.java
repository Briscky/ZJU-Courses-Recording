//: Destination.java

interface Destination {
	String readLabel();
}
