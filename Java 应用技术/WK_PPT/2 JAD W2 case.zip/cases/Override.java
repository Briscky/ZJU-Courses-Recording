/**
 * <<Class summary>>
 *
 * @author Kai Weng &lt;&gt;
 * @version $Rev$
 */
class Base {
	public int i=10;
	
    public Base() {
        System.out.println("Base()");
		this.f();
    }

	void f() {
		System.out.println("Base.f()"+i);
	}
	// }}}
}

public class Override extends Base {
	public int i=20;
	
	public Override() {
		f();
	}
	
	void f() {
		System.out.println("Override.f()"+i);
	}
	
	public static void main(String[] args) {
		Base b = new Override();
		b.f();
	}
}
