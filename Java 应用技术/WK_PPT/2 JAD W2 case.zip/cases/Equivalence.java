//: Equivalence.java
public class Equivalence {
	public static void main(String[] args) {
		Integer n1 = 127;//new Integer(47);
		Integer n2 = 127;//new Integer(47);
		int i = n1;
		System.out.println(n1 == n2);
		System.out.println(n1 != n2);
	}
} ///:~
