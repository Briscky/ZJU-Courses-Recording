public class SimpleRunnable implements Runnable {
	private String message;
	
	public static void main(String[] args) throws Exception {
		SimpleRunnable r1 = new SimpleRunnable("Hello");
		Thread t1 = new Thread(r1);
		t1.start();
		for (int i=0;i<100;i++) {
			t1.sleep(100);
			System.out.println("Bye-bye");
		}
		//System.out.println("Bye-bye");
	}
	
	public SimpleRunnable(String message) {
		this.message = message;
	}
	
	public void run() {
		for (int i=0;i<100;i++) {
			System.out.println(message);
		}
	}
}
