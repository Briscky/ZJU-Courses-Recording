class TheData {
	int x;
	float f;
}

class FirstRunnable implements Runnable {
	TheData sharedData;
	
	public FirstRunnable(TheData toUse) {
		sharedData = toUse;
	}
	
	public void run() {
		//	do something
	}
}

class SecondRunnable implements Runnable {
	TheData sharedData;
	
	public SecondRunnable(TheData toUse) {
		sharedData = toUse;
	}
	
	public void run() {
		//	do something
	}
}

public class TwoRunnable {
	public static void main(String[] args) {
		TheData data = new TheData();
		FirstRunnable f = new FirstRunnable(data);
		SecondRunnable s = new SecondRunnable(data);
		Thread t1 = new Thread(f);
		Thread t2 = new Thread(s);
		t1.start();
		t2.start();
	}
}