public class SimpleRunnable2 implements Runnable {
	private String message;
	
	public static void main(String[] args) {
		SimpleRunnable r1 = new SimpleRunnable("Hello");
		SimpleRunnable r2 = new SimpleRunnable("Good-bye");
		Thread t1 = new Thread(r1);
		Thread t2 = new Thread(r2);
		t1.start();
		t2.start();
	}
	
	public SimpleRunnable2(String message) {
		this.message = message;
	}
	
	public void run() {
		for (;;) {
			System.out.println(message);
		}
	}
}