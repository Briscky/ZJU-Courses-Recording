class A {
	void f(B b) {
		b.f();
	}
}

class B {
	void f() {
		System.out.println("I'm here");
	}
}

public class TwoObj {
	public static void main(String[] args) {
		A a = new A();
		B b = new B();
		a.f(b);
	}
}