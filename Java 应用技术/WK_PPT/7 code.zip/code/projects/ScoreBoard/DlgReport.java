import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.net.URL;
import java.util.ArrayList;
import javax.swing.table.*;
import javax.swing.filechooser.*;
import java.io.*;

public class DlgReport extends JDialog {
	static String[] cname = {
		"序号","姓名","报道文章分","技术文章分","图片分","总分"
	};
	ArrayList<ArrayList<String>> data;
	public DlgReport(JFrame frame, final ArrayList<ArrayList<String>> v) {
		super(frame,"统计结果",true);
		data = v;
		AbstractTableModel dataModel = new AbstractTableModel() {
			public int getColumnCount() { return cname.length; }
          	public int getRowCount() { return v.size();}
          	public Object getValueAt(int row, int col) {
				return v.get(row).get(col);
			}
			public String getColumnName(int col) {
				return cname[col];
			}
			public boolean isCellEditable(int row, int col) {
				return false;
			}
      	};
		JTable table = new JTable(dataModel);
		JScrollPane scrollpane = new JScrollPane(table);
		add(scrollpane,BorderLayout.CENTER);
		JPanel pane = new JPanel();
		pane.setLayout(new FlowLayout());
		JButton btnExcel = new JButton("生成Excel文件");
		JButton btnHTML = new JButton("生成HTML文件");
		btnExcel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				genXLS();
			}
		});btnHTML.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				genHTML();
			}
		});
		pane.add(btnExcel);
		pane.add(btnHTML);
		add(pane,BorderLayout.SOUTH);
	}
	
	private void genHTML() {
		JFileChooser chooser = new JFileChooser();
		chooser.setDialogTitle("保存为HTML文件");
		chooser.setMultiSelectionEnabled(false);
		chooser.setAcceptAllFileFilterUsed(false);
		chooser.addChoosableFileFilter(new javax.swing.filechooser.FileFilter() {
			public boolean accept(File f) {
				String s = f.getName();
				boolean ret = false;
				if ( f.isDirectory() || s.endsWith(".html") || s.endsWith(".htm") ) 
					ret = true;
				return ret;
			}
			public String getDescription() {
				return "HTML files(*.html;*.htm)";
			}
		});
	    int returnVal = chooser.showSaveDialog(this);
	    if ( returnVal == JFileChooser.APPROVE_OPTION ) {
			File selFile = chooser.getSelectedFile();
			if ( selFile.exists() ) {
				if ( JOptionPane.showConfirmDialog(this,selFile.getName()+"已经存在，要替换么？",
					"替换?",JOptionPane.YES_NO_OPTION) == JOptionPane.NO_OPTION ) {
						return;
					}
			}
			try {
				PrintWriter pw = new PrintWriter(
					new BufferedWriter(
						new OutputStreamWriter(
							new FileOutputStream(selFile))));
				pw.println("<html><body><table border='1'>");
				pw.print("<tr>");
				for ( String s: cname ) {
					pw.print("<th>"+s+"</th>");
				}
				pw.println("</tr>");
				for ( ArrayList<String> a : data ) {
					pw.print("<tr>");
					for ( String s: a ) {
						pw.print("<td>"+s+"</td>");
					}
					pw.println("</tr>");
				}
				pw.println("</table></body></html>");
				pw.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
	    }
	}
	
	private void genXLS() {
		JFileChooser chooser = new JFileChooser();
		chooser.setDialogTitle("保存为Excel文件");
		chooser.setMultiSelectionEnabled(false);
		chooser.setAcceptAllFileFilterUsed(false);
		chooser.addChoosableFileFilter(new javax.swing.filechooser.FileFilter() {
			public boolean accept(File f) {
				String s = f.getName();
				boolean ret = false;
				if ( f.isDirectory() || s.endsWith(".xls") ) 
					ret = true;
				return ret;
			}
			public String getDescription() {
				return "MS Excel files(*.xls)";
			}
		});
	    int returnVal = chooser.showSaveDialog(this);
	    if ( returnVal == JFileChooser.APPROVE_OPTION ) {
			File selFile = chooser.getSelectedFile();
			if ( selFile.exists() ) {
				if ( JOptionPane.showConfirmDialog(this,selFile.getName()+"已经存在，要替换么？",
					"替换?",JOptionPane.YES_NO_OPTION) == JOptionPane.NO_OPTION ) {
						return;
					}
			}
			try {
				jxl.write.WritableWorkbook book = jxl.Workbook.createWorkbook(selFile);
				jxl.write.WritableSheet sheet = book.createSheet("统计结果",0);
				for ( int i=0; i<cname.length; ++i ) {
					sheet.addCell(new jxl.write.Label(i,0,cname[i]));
				}
				for ( int i=0; i<data.size(); ++i ) {
					ArrayList<String> a = data.get(i);
					for ( int j=0; j<a.size(); ++j ) {
						String s = a.get(j);
						sheet.addCell(new jxl.write.Label(j,i+1,s));
					}
				}
				book.write();
				book.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
	    }
	}
}