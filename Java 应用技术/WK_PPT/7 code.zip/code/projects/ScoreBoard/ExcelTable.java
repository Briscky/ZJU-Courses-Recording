import java.io.*; 
import java.util.*;
import jxl.*;
import jxl.write.*;
import javax.swing.*;
import javax.swing.table.*;

public class ExcelTable extends JTable {
	private Workbook workbook;
	private WritableWorkbook bookcopy;
	private Sheet sheet;
	private WritableSheet sheetcopy;
	private boolean bModified =false;
	private AbstractTableModel dataModel;
	
	public ExcelTable(String fileName, int sheetNum) throws IOException {
		this(new File(fileName), sheetNum);
	}
	
	public ExcelTable(File file, int sheetNum) throws IOException {
		try {
			String fileName = file.getName();
			file.renameTo(new File(fileName+".orig"));
			workbook = Workbook.getWorkbook(new File(fileName+".orig"));
			bookcopy = Workbook.createWorkbook(new File(fileName), workbook);
			sheet = workbook.getSheet(sheetNum);
			sheetcopy = bookcopy.getSheet(sheetNum);
			dataModel = new AbstractTableModel() {
				public int getColumnCount() { return sheetcopy.getColumns(); }
	          	public int getRowCount() { return sheetcopy.getRows()-1;}
	          	public Object getValueAt(int row, int col) { 
					return sheetcopy.getWritableCell(col,row+1).getContents();
				}
				public String getColumnName(int col) {
					return sheet.getCell(col,0).getContents();
				}
				public boolean isCellEditable(int row, int col) {
					return true;
				}
				public void setValueAt(Object value, int row, int col) {
					try {
						WritableCell cell = sheetcopy.getWritableCell(col, row+1); 
						System.out.println(cell.getType());
						if ( cell.getType() == CellType.LABEL ) { 
							jxl.write.Label l = (Label) cell; 
							l.setString((String)value); 
						} if ( cell.getType() == CellType.NUMBER ) { 
							jxl.write.Number n = (jxl.write.Number) cell; 
							n.setValue(Double.parseDouble((String)value)); 
						} else if ( cell.getType() == CellType.EMPTY ) {
							jxl.write.Label label = new Label(col, row+1, (String)value); 
							sheetcopy.addCell(label);
						}
						bModified = true;
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
	      	};
			setModel(dataModel);
		} catch ( Exception e) {
			e.printStackTrace();
			throw new IOException();
		}
	}

	public void addRow() {
		//sheetcopy.insertRow(getSelectedRow());
		try {
			jxl.write.Number num = new jxl.write.Number(0,sheetcopy.getRows(),sheetcopy.getRows());
			sheetcopy.addCell(num);
			dataModel.fireTableDataChanged();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void delRow() {
		try {
			int row = getSelectedRow();
			if ( row ==-1 ) {
				JOptionPane.showMessageDialog(this,"请选择要删除的记录");
			} else {
				sheetcopy.removeRow(row+1);
				dataModel.fireTableDataChanged();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public ArrayList<ArrayList<String>> search(String name) {
		ArrayList<ArrayList<String>> v = new ArrayList<ArrayList<String>>();
		for ( int i=1; i<sheetcopy.getRows(); ++i ) {
			if ( sheetcopy.getWritableCell(1,i).getContents().compareTo(name) ==0 ) {
				ArrayList<String> a = new ArrayList<String>();
				for ( int j=0; j<sheetcopy.getColumns(); ++j ) {
					a.add(sheetcopy.getWritableCell(j,i).getContents());
				}
				v.add(a);
			}
		}
		return v;
	}
	
	public ArrayList<ArrayList<String>> report() {
		class RprtRecord {
			int nTech =0;
			int nRept =0;
			int nPics =0;
		}
		HashMap<String, RprtRecord> m = new HashMap<String, RprtRecord>();
		for ( int i=1; i<sheetcopy.getRows(); ++i ) {
			String name = sheetcopy.getWritableCell(1,i).getContents();
			RprtRecord r = m.get(name);
			if ( r==null ) {
				r = new RprtRecord();
				m.put(name, r);
			}
			try {
				if ( sheetcopy.getWritableCell(5,i).getContents().length()>0 )
 					r.nTech += Integer.parseInt(sheetcopy.getWritableCell(5,i).getContents());
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {
				if ( sheetcopy.getWritableCell(6,i).getContents().length()>0 )
					r.nRept += Integer.parseInt(sheetcopy.getWritableCell(6,i).getContents());
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {
				if ( sheetcopy.getWritableCell(7,i).getContents().length()>0 )
					r.nPics += Integer.parseInt(sheetcopy.getWritableCell(7,i).getContents());
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		ArrayList<ArrayList<String>> v = new ArrayList<ArrayList<String>>();
		Set<String> ks = m.keySet();
		Iterator<String> it = ks.iterator();
		int cnt=1;
		while ( it.hasNext() ) {
			String name = it.next();
			RprtRecord r = m.get(name);
			ArrayList<String> a = new ArrayList<String>();
			a.add(String.valueOf(cnt));
			a.add(name);
			a.add(String.valueOf((double)r.nTech*1.5/100));
			a.add(String.valueOf((double)r.nRept/100));
			a.add(String.valueOf((double)r.nPics/2));
			a.add(String.valueOf((double)r.nTech*1.5/100+(double)r.nRept/100+(double)r.nPics/2));
			v.add(a);
			cnt++;
		}
		return v;
	}
	
	public final boolean isModified() {
		return bModified;
	}
	
	public void close() throws Exception {
		bookcopy.write();
		bookcopy.close();
	}
}