import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.net.URL;
import java.util.ArrayList;
import javax.swing.table.*;

public class DlgFind extends JDialog {
	static String[] cname = {
		"序号","姓名","呼号","期刊号","文章题目","技术文章字数","报道文章字数","图片数"
	};
	int nTech=0;
	int nRept=0;
	int nPics=0;
	public DlgFind(JFrame frame, final ArrayList<ArrayList<String>> v) {
		super(frame,"查询结果",true);
		for ( int i=0; i<v.size(); ++i ) {
			try {
				if ( v.get(i).get(5).length()>0 )
 					nTech += Integer.parseInt(v.get(i).get(5));
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {
				if ( v.get(i).get(6).length()>0 )
					nRept += Integer.parseInt(v.get(i).get(6));
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {
				if ( v.get(i).get(7).length()>0 )
					nPics += Integer.parseInt(v.get(i).get(7));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		System.out.println("t"+nTech+"r+"+nRept+"p"+nPics);
		AbstractTableModel dataModel = new AbstractTableModel() {
			public int getColumnCount() { return cname.length; }
          	public int getRowCount() { return v.size()+2;}
          	public Object getValueAt(int row, int col) {
	 			if ( row <v.size() )
					return v.get(row).get(col);
				else if ( row==v.size() ) {
					switch (col) {
						case 0: return "合计";
						case 5: return String.valueOf(nTech);
						case 6: return String.valueOf(nRept);
						case 7: return String.valueOf(nPics);
						default: return "";
					}
				} if ( row == v.size()+1 ) 	{
					switch (col) {
						case 0: return "计分";
						case 5: return String.valueOf((double)nTech*1.5/100);
						case 6: return String.valueOf((double)nRept/100);
						case 7: return String.valueOf((double)nPics/2);
						default: return "";
					}
				}
				return "";
			}
			public String getColumnName(int col) {
				return cname[col];
			}
			public boolean isCellEditable(int row, int col) {
				return false;
			}
      	};
		JTable table = new JTable(dataModel);
		JScrollPane scrollpane = new JScrollPane(table);
		add(scrollpane);
		
	}
}