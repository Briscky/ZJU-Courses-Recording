import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.net.URL;
import java.util.ArrayList;

public class ScoreBoard extends JFrame {
	private ExcelTable table = null;
	private ScoreBoard theFrame;
	
	public ScoreBoard() {
		super("投稿记录");
		theFrame = this;
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.out.println("closing");
				exit();
			}
			public void windowClosed(WindowEvent e) {
				System.out.println("closed");
				exit();
			}
		});
		//	The menu
		JMenuBar mb = new JMenuBar();
		JMenu file = new JMenu("文件");
		JMenu record = new JMenu("记录");
		JMenu statics = new JMenu("统计");
		JMenu help = new JMenu("帮助");
		makeMenuItem(file,"退出","退出",new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				exit();
			}
		});
		makeMenuItem(record,"增加","增加新记录",new AddListener());
		makeMenuItem(record,"删除","删除记录",new DelListener());
		makeMenuItem(statics,"查询","查询个人记录",new SearchListener());
		makeMenuItem(statics,"统计","统计报表",new ReportListener());
		makeMenuItem(help,"关于","关于投稿记录",new AboutListener());
		mb.add(file);
		mb.add(record);
		mb.add(statics);
		mb.add(help);
		setJMenuBar(mb);
		//	The toolbar
		JToolBar toolBar = new JToolBar();
		makeToolBarButton(toolBar,"add-32x32","add","增加新记录","增加",new AddListener());
		makeToolBarButton(toolBar,"delete-32x32","delete","删除当前记录","删除",new DelListener());
		toolBar.addSeparator();
		makeToolBarButton(toolBar,"find-32x32","search","查询个人记录","查询",new SearchListener());
		makeToolBarButton(toolBar,"text-file-32x32","statics","统计报表","报表",new ReportListener());
		toolBar.addSeparator();
		makeToolBarButton(toolBar,"info-about-32x32","statics","关于本软件","关于",new AboutListener());	
		add(toolBar, BorderLayout.PAGE_START);
		//	The table pane
		try {
			table = new ExcelTable("score.xls",0);
			JScrollPane scrollPane = new JScrollPane(table);
			add(scrollPane, BorderLayout.CENTER);
		} catch (Exception e) {
			e.printStackTrace();
			exit();
		}
	}
	
	private void makeMenuItem(JMenu menu,
							  String menuText,
							  String toolTipText,
							  ActionListener listener) {
		JMenuItem m = new JMenuItem(menuText);
		m.setToolTipText(toolTipText);
		m.addActionListener(listener);
		menu.add(m);						
	}
	
	private void makeToolBarButton(JToolBar toolBar,
								   String imageName,
	                               String actionCommand,
	                               String toolTipText,
	                               String altText,
								   ActionListener listener) {
	    //Look for the image.
	    String imgLocation = "images/"
	                         + imageName
	                         + ".png";
	    URL imageURL = ScoreBoard.class.getResource(imgLocation);

	    //Create and initialize the button.
	    JButton button = new JButton();
	    button.setActionCommand(actionCommand);
	    button.setToolTipText(toolTipText);
	    button.addActionListener(listener);

	    if (imageURL != null) {                      //image found
	        button.setIcon(new ImageIcon(imageURL, altText));
	    } else {                                     //no image found
	        button.setText(altText);
	        System.err.println("Resource not found: " + imgLocation);
	    }
		
		toolBar.add(button);
	}
	
	//	----------------------------------------------------------------------
	//	menu command listeners
	private void exit() {
		try {
			table.close();
			System.exit(0);
		} catch ( Exception e) {
			e.printStackTrace();
		}
	}
	
	private class AddListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			table.addRow();
		}
	}
	
	private class DelListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			table.delRow();
		}
	}
	
	private class SearchListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			String name = JOptionPane.showInputDialog(
				theFrame,"输入要查找的姓名：","查找作者",
				JOptionPane.QUESTION_MESSAGE);
			//System.out.println(name);
			ArrayList<ArrayList<String>> v = table.search(name);
			for ( int i=0; i<v.size(); ++i ) {
				for ( int j=0; j<v.get(i).size(); ++j ) {
					System.out.println(v.get(i).get(j));
				}
			}
			DlgFind dlg = new DlgFind(theFrame,v);
			dlg.pack();
			dlg.setVisible(true);
		}
	}
	
	private class ReportListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			ArrayList<ArrayList<String>> v = table.report();
			for ( int i=0; i<v.size(); ++i ) {
				for ( int j=0; j<v.get(i).size(); ++j ) {
					System.out.print(v.get(i).get(j)+" ");
				}
				System.out.println();
			}
			DlgReport dlg = new DlgReport(theFrame,v);
			dlg.pack();
			dlg.setVisible(true);
		}
	}
	
	private class AboutListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			JOptionPane.showMessageDialog(theFrame,"稿件统计 (C)2007 BA5AG");
		}
	}
	
	//	-------------------------------------------------------------------------
	public static void main(String[] args) {
		JFrame frame = new ScoreBoard();
		frame.pack();
		frame.setVisible(true);
	}
}